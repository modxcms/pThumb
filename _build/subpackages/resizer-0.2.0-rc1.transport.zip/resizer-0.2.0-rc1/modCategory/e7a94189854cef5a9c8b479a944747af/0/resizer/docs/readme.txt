Resizer

A light-weight, modern image resizer for MODX.

Author: Jason Grant
Copyright 2013

Documentation, bug reports, feature requests:
https://github.com/oo12/Resizer