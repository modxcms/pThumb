----------------------------
pThumb, a fork of phpThumbOf
----------------------------

It's best to uninstall phpThumbOf before installing pThumb.

pThumb is a fork of phpThumbOf 1.4.0, originally developed by
Shaun McCormick <shaun@modx.com>
License: GNU GPLv2

Please visit the GitHub page for documentation or to report bugs:
https://github.com/oo12/phpThumbOf


Usage:

[[+imageUrl:phpthumbof=`w=234&h=123&zc=1`]]

Any phpThumb-compatible options can be passed into the filter.